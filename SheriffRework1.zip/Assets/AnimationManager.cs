using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using static UnityEditor.Experimental.GraphView.GraphView;

public class AnimationManager : MonoBehaviour
{
    private Animator animator;
    public string currentState;

    private SimpleMovement MovementScript;
    private DodgeRoll RollScript;
    private Melee MeleeScript;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        MovementScript = GetComponent<SimpleMovement>();
        RollScript = GetComponent<DodgeRoll>();
        MeleeScript = GetComponent<Melee>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        /*if (CombatScript.isPunching)
            changeAnimationState("Punch");
        else */
        if (currentState != "Land" || !MovementScript.isGrounded)
        {
            if (RollScript.isRolling)
                changeAnimationState("DodgeRoll");
            else if (MeleeScript.isAttacking)
                changeAnimationState("Knife");
            else if (MovementScript.isGrounded)
            {
                if (currentState == "FallingJump")
                {
                    changeAnimationState("Land");
                    StartCoroutine(LandTime());
                }
                else if (!MovementScript.slide)
                {
                    if (MovementScript.xDir == "left" || MovementScript.xDir == "right")
                        changeAnimationState("Walk");
                    else
                        changeAnimationState("Idle");
                }
                //else if (MovementScript.rb.velocity.x != 0)
                //changeAnimationState("Slide");
                /*
                else
                    changeAnimationState("Crouch");*/
            }
            else
            {
                /*if(MovementScript.rb.velocity.x > 0)
                    MovementScript.sr.flipX = true;
                else if (MovementScript.rb.velocity.x < 0)
                    MovementScript.sr.flipX = false;*/
                /*if (MovementScript.isWallRunning)
                {
                    changeAnimationState("WallRun");
                }
                else if (MovementScript.isOnLeftWall && MovementScript.xDir == "left")
                {
                    MovementScript.sr.flipX = true;
                    changeAnimationState("WallSlide");
                }
                else if (MovementScript.isOnRightWall && MovementScript.xDir == "right")
                {
                    MovementScript.sr.flipX = false;
                    changeAnimationState("WallSlide");
                }
                else*/
                if (MovementScript.rb.velocity.y > 8)
                    changeAnimationState("RisingJump");
                else if (MovementScript.rb.velocity.y < -8)
                    changeAnimationState("FallingJump");
                else
                    changeAnimationState("MiddleJump");
            }
        }
    }

    private void changeAnimationState(string newState)
    {
        if (currentState == newState)
            return;

        animator.Play(newState);

        currentState = newState;
    }
    IEnumerator LandTime()
    {
        yield return new WaitForSeconds(animator.GetCurrentAnimatorStateInfo(0).length);
        currentState = "Idle";
    }
}
