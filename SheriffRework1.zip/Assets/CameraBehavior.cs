using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraBehavior : MonoBehaviour
{
    private Camera cam;
    private GameObject player;
    private Transform mouse;

    [SerializeField] private float lerpNum = 0.005f;

    // Start is called before the first frame update
    void Start()
    {
        cam = GetComponent<Camera>();
        player = GameObject.Find("Player");
        mouse = GameObject.Find("Player Relative Mouse").transform;
        
        Application.targetFrameRate = 60;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //transform.position = new Vector3(player.transform.position.x, player.transform.position.y, -10);


        transform.position = Vector3.Lerp(transform.position, new Vector3(player.transform.position.x, transform.position.y, -10), lerpNum);



    }
}
