using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ReserveAmmoText : MonoBehaviour
{
    TextMeshPro ReserveAmmoTMP;

    private RevolverBarrel barrel;

    // Start is called before the first frame update
    void Start()
    {
        ReserveAmmoTMP = GetComponent<TextMeshPro>();
        barrel = GameObject.Find("Barrel").GetComponent<RevolverBarrel>();
    }

    // Update is called once per frame
    void Update()
    {
        ReserveAmmoTMP.text = "" + barrel.reserveAmmo;
    }
}
