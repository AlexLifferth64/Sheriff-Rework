using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RevolverBarrel : MonoBehaviour
{
    public int barrelNum = 0;
    public bool[] barrel = {true, true, true, true, true, true};
    public int reserveAmmo = 6;
    public GameObject[] bullets;
    public bool isReloading;
    public bool isPenalized = false;

    private int shakeCount = 0; // used for barrel shaking effect

    Gun gun;

    private void Start()
    {
        bullets = new GameObject[6];

        bullets[0] = GameObject.Find("Bullet0");
        bullets[1] = GameObject.Find("Bullet1");
        bullets[2] = GameObject.Find("Bullet2");
        bullets[3] = GameObject.Find("Bullet3");
        bullets[4] = GameObject.Find("Bullet4");
        bullets[5] = GameObject.Find("Bullet5");

        gun = GameObject.Find("Player").GetComponent<Gun>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R) && !isPenalized)
        {
            if (!isReloading)
            {
                StartCoroutine(BarrelPenaltyTime(0.01f));
            }
            else
            {
                isReloading = false;
                GameObject.Find("Player Relative Mouse").GetComponent<PlayerRelativeMouse>().lockMouse = false;
            }
        }

        if (!isReloading)
            SetBarrelAndBulletSpriteRenderers(false);
        else
            SetBarrelAndBulletSpriteRenderers(true);

        if (!isPenalized)
        {
            shakeCount = 0;

            if(Input.GetKeyDown(KeyCode.Alpha1))
            {
                bullets[BarrelNumDeterminer(barrelNum, false)].GetComponent<SpriteRenderer>().color = Color.yellow;
            }

            if (Input.GetKeyDown(KeyCode.Q) || Input.GetKeyDown(KeyCode.H))
            {
                barrelNum = BarrelNumDeterminer(barrelNum, false);
                //Debug.Log(barrelNum);
                //Debug.Log(barrel[barrelNum]);
            }
            else if (Input.GetKeyDown(KeyCode.E) || Input.GetKeyDown(KeyCode.J))
            {
                barrelNum = BarrelNumDeterminer(barrelNum, true);
                //Debug.Log(barrelNum);
                //Debug.Log(barrel[barrelNum]);
            }

            if(Input.GetKeyDown(KeyCode.G) || Input.GetKeyDown(KeyCode.Mouse3)) // Quick Reload
            {
                if (barrel[barrelNum] || reserveAmmo <= 0)
                    StartCoroutine(PenaltyTime(0.4f));
                else
                {
                    barrel[barrelNum] = true;
                    reserveAmmo--;
                }
                UpdateBarrelVisuals();
            }

            if (Input.GetKeyDown(KeyCode.Mouse0) || Input.GetKeyDown(KeyCode.B))
            {
                if (isReloading)
                {
                    if (barrel[barrelNum] || reserveAmmo <= 0)
                        StartCoroutine(PenaltyTime(0.4f));
                    else
                    {
                        barrel[barrelNum] = true;
                        reserveAmmo--;
                    }
                }
                else if(gun.fire)
                {
                    if (!barrel[barrelNum])
                        StartCoroutine(PenaltyTime(0.3f));
                    else
                        barrel[barrelNum] = false;
                    barrelNum = BarrelNumDeterminer(barrelNum, true);
                }
                else
                {
                    barrelNum = BarrelNumDeterminer(barrelNum, true);
                    StartCoroutine(PenaltyTime(0.3f));
                }

                UpdateBarrelVisuals();
                //Debug.Log(barrel[0] + " " + barrel[1] + " " + barrel[2] + " " + barrel[3] + " " + barrel[4] + " " + barrel[5]);
            }
        }
        else
        {
            ShakeAffect(-0.3f, 0.3f, shakeCount);
            shakeCount++;
        }
    }

    private void FixedUpdate()
    {
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, 0, barrelNum * 60), Time.deltaTime * 20);
    }

    private void UpdateBarrelVisuals()
    {
        for (int i = 0; i <= 5; i++)
        {
            //Debug.Log(barrel[i]);
            if (barrel[i])
                bullets[i].GetComponent<SpriteRenderer>().color = Color.white;
            else
                bullets[i].GetComponent<SpriteRenderer>().color = Color.black;
        }
    }

    private int BarrelNumDeterminer(int num, bool add) // true adds 1, false subtracts 1
    {
        if (num == 0 && !add)
            return 5;
        else if (num == 5 && add)
            return 0;
        else if (add)
            return num + 1;
        else
            return num - 1;
    }

    private void SetBarrelAndBulletSpriteRenderers(bool enable)
    {
        GetComponent<SpriteRenderer>().enabled = enable;

        foreach(GameObject bullet in bullets)
        {
            bullet.GetComponent<SpriteRenderer>().enabled = enable;
        }
    }

    IEnumerator PenaltyTime(float time)
    {
        isPenalized = true;
        yield return new WaitForSeconds(time);
        isPenalized = false;
        transform.localPosition = new Vector2(0, 5);
    }

    IEnumerator BarrelPenaltyTime(float time)
    {
        isPenalized = true;
        yield return new WaitForSeconds(time);
        isPenalized = false;
        isReloading = true;

        //GameObject.Find("Player Relative Mouse").GetComponent<PlayerRelativeMouse>().ResetMousePos();
        //GameObject.Find("Player Relative Mouse").GetComponent<PlayerRelativeMouse>().lockMouse = true;

        transform.localPosition = new Vector2(0, 5);
    }
    private void ShakeAffect(float lower, float upper, int count)//, float angleRange)
    {
        if(count % 2 == 0)
        {
            transform.localPosition = new Vector2(0, 5);
        }
        else
        {
            float y = Random.Range(lower, upper);
            float x = Random.Range(lower, upper);
            //float angle = Random.Range(-angleRange, angleRange);

            transform.localPosition = new Vector2(transform.localPosition.x + x, transform.localPosition.y + y);
        }
    }
}
