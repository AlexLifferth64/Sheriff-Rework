using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;

public class Weapon : MonoBehaviour
{
    public Animator animator;

    GameObject player;

    public Camera cam;
    private SpriteRenderer gunSr;
    private Transform playerPos;
    public Transform firePoint;
    private Transform gunPivot;

    public float angle;
    public Vector2 mousePos;
    public Vector2 lookDir;
    Quaternion rotation;

    //public GrapplingHook GrapplingHookScript;
    //private Gun GunScript;
    //private Shotgun ShotgunScript;
    private Movement MovementScript;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player"); // SAME HERE

        playerPos = player.GetComponent<Transform>();
        cam = GameObject.Find("Camera").GetComponent<Camera>(); // SCRIPT WILL NOT WORK IF CAMERA IS NAMED ANYTHING ELSE BUT "Camera"
        gunPivot = GameObject.Find("PlayerGunPivot").GetComponent<Transform>();

        gunSr = GetComponentInChildren<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        mousePos = GameObject.Find("Player Relative Mouse").transform.position;
        lookDir = mousePos - (Vector2)gunPivot.position;

        //transform.position = playerPos.position;
        /*if (transform.rotation.z > 0)
        {
            transform.rotation = Quaternion.Euler(0, 180, transform.rotation.z);
        }
        if (transform.rotation.z < 0)
        {
            transform.rotation = Quaternion.Euler(0, 0, transform.rotation.z);
        }*/
        angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg;
        if (angle < 180)
        {
            rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            //Debug.Log("yeeeeeeeee");
        }
        else
        {
            rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            //Debug.Log("nooooooooo");
        }

        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 1);
        if ((angle > 90 || angle < -90))// && MovementScript.hotbar != 3 && MovementScript.hotbar != 4)
        {
            gunSr.flipY = true;
            //MovementScript.sr.flipX = false;
        }
        else
        {
            gunSr.flipY = false;
            /*if(MovementScript.hotbar != 3 && MovementScript.hotbar != 4)
            {
                MovementScript.sr.flipX = true;
            }*/
        }
        /*animator.SetBool("isShooting", GunScript.fire == true && MovementScript.hotbar == 2);
        animator.SetBool("isShootingShotgun", ShotgunScript.fire == true && MovementScript.hotbar == 1);
        animator.SetBool("isReloading", GunScript.canFire == false || ShotgunScript.canFire == false);*/
    }
}
